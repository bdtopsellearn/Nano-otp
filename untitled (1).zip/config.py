# ══════════════════════════════════════════════════════════════════════════════
#  ⚙️  USER SETTINGS — এখানে শুধু এই 3টি জিনিস পরিবর্তন করুন
# ══════════════════════════════════════════════════════════════════════════════

# 1) Your Bot Token (obtained from BotFather)
BOT_TOKEN = '8724671399:AAFh1T8G-QqwtpI4A1MwMyc4h2uTiTpxrVU'

# 2) Admin Telegram User ID (numeric ID of your Telegram account)
PROTECTED_ADMIN_IDS = [7831629041]

# 3) Default OTP Group Chat ID — সব OTP message এখানে যাবে
DEFAULT_GROUP_CHAT_ID = -1004382561394

PROTECTED_ADMINS = ['bd_top_admin']

OTP_GROUP_LINK = "https://t.me/Top_otp_receive"

# ── SMS Hadi Panel ─────────────────────────────────────────────────────────────
SMS_HADI_BASE       = "http://smshadi.net"
SMS_HADI_LOGIN_URL  = f"{SMS_HADI_BASE}/login"
SMS_HADI_SIGNIN_URL = f"{SMS_HADI_BASE}/signin"
SMS_HADI_STATS_URL  = f"{SMS_HADI_BASE}/agent/SMSCDRStats"
SMS_HADI_AJAX_URL   = f"{SMS_HADI_BASE}/agent/res/data_smscdr.php"

SMS_HADI_USERNAME = ''
SMS_HADI_PASSWORD = ''

# ── Konekta Premium Panel ──────────────────────────────────────────────────────
KONEKTA_BASE       = "https://konektapremium.net"
KONEKTA_LOGIN_URL  = f"{KONEKTA_BASE}/sign-in"
KONEKTA_SIGNIN_URL = f"{KONEKTA_BASE}/signin"
KONEKTA_STATS_URL  = f"{KONEKTA_BASE}/client/SMSCDRStats"
KONEKTA_AJAX_URL   = f"{KONEKTA_BASE}/client/res/data_smscdr.php"

KONEKTA_USERNAME = ''
KONEKTA_PASSWORD = ''

# ── MSI SMS Panel ──────────────────────────────────────────────────────────────
MSI_SMS_BASE       = "http://145.239.130.45/ints"
MSI_SMS_LOGIN_URL  = f"{MSI_SMS_BASE}/login"
MSI_SMS_SIGNIN_URL = f"{MSI_SMS_BASE}/signin"
MSI_SMS_STATS_URL  = f"{MSI_SMS_BASE}/agent/SMSCDRStats"
MSI_SMS_AJAX_URL   = f"{MSI_SMS_BASE}/agent/res/data_smscdr.php"

MSI_SMS_USERNAME = ''
MSI_SMS_PASSWORD = ''

SMS_MONITOR_INTERVAL = 16

# ── Number Panel ───────────────────────────────────────────────────────────────
NUMBER_PANEL_BASE       = "http://51.89.99.105/NumberPanel"
NUMBER_PANEL_LOGIN_URL  = f"{NUMBER_PANEL_BASE}/login"
NUMBER_PANEL_SIGNIN_URL = f"{NUMBER_PANEL_BASE}/signin"
NUMBER_PANEL_STATS_URL  = f"{NUMBER_PANEL_BASE}/client/SMSCDRStats"
NUMBER_PANEL_AJAX_URL   = f"{NUMBER_PANEL_BASE}/client/res/data_smscdr.php"

NUMBER_PANEL_USERNAME = ''
NUMBER_PANEL_PASSWORD = ''

NUMBER_PANEL_INTERVAL = 16

# ── Purple SMS Panel ───────────────────────────────────────────────────────────
PURPLE_SMS_BASE       = "http://85.195.94.50/sms"
PURPLE_SMS_LOGIN_URL  = "http://85.195.94.50/sms/SignIn"
PURPLE_SMS_SIGNIN_URL = "http://85.195.94.50/sms/signmein"
PURPLE_SMS_STATS_URL  = "http://85.195.94.50/sms/dialer/SMSReports"
PURPLE_SMS_AJAX_URL   = "http://85.195.94.50/sms/dialer/res/data_smscdr.php"

PURPLE_SMS_USERNAME = ''
PURPLE_SMS_PASSWORD = ''

# ── Proof SMS Panel ────────────────────────────────────────────────────────────
PROOF_SMS_BASE       = "http://217.182.195.194/ints"
PROOF_SMS_LOGIN_URL  = "http://217.182.195.194/ints/login"
PROOF_SMS_SIGNIN_URL = "http://217.182.195.194/ints/signin"

PROOF_SMS_USERNAME = ''
PROOF_SMS_PASSWORD = ''

# ── Lamix SMS Panel ────────────────────────────────────────────────────────────
LAMIX_SMS_BASE       = "http://51.210.208.26/ints"
LAMIX_SMS_LOGIN_URL  = "http://51.210.208.26/ints/login"
LAMIX_SMS_SIGNIN_URL = "http://51.210.208.26/ints/signin"

LAMIX_SMS_USERNAME = ''
LAMIX_SMS_PASSWORD = ''

# ── Seven 1 Tel Panel ──────────────────────────────────────────────────────────
SEVEN1TEL_BASE       = "http://94.23.120.156/ints"
SEVEN1TEL_LOGIN_URL  = "http://94.23.120.156/ints/login"
SEVEN1TEL_SIGNIN_URL = "http://94.23.120.156/ints/signin"
SEVEN1TEL_STATS_URL  = "http://94.23.120.156/ints/agent/SMSCDRStats"
SEVEN1TEL_AJAX_URL   = "http://94.23.120.156/ints/agent/res/data_smscdr.php"

SEVEN1TEL_USERNAME = ''
SEVEN1TEL_PASSWORD = ''

SEVEN1TEL_INTERVAL = 16

# ── Flex SMS Panel ─────────────────────────────────────────────────────────────
MAIT_SMS_BASE       = "http://168.119.13.175/ints"
MAIT_SMS_LOGIN_URL  = "http://168.119.13.175/ints/login"
MAIT_SMS_SIGNIN_URL = "http://168.119.13.175/ints/signin"
MAIT_SMS_STATS_URL  = "http://168.119.13.175/ints/agent/SMSCDRStats"
MAIT_SMS_AJAX_URL   = "http://168.119.13.175/ints/agent/res/data_smscdr.php"

MAIT_SMS_USERNAME = ''
MAIT_SMS_PASSWORD = ''

MAIT_SMS_INTERVAL = 16

# ── Zento SMS Panel ────────────────────────────────────────────────────────────
ZENTO_SMS_BASE       = "http://54.38.176.48/ints"
ZENTO_SMS_LOGIN_URL  = f"{ZENTO_SMS_BASE}/login"
ZENTO_SMS_SIGNIN_URL = f"{ZENTO_SMS_BASE}/signin"
ZENTO_SMS_STATS_URL  = f"{ZENTO_SMS_BASE}/client/SMSCDRStats"
ZENTO_SMS_AJAX_URL   = f"{ZENTO_SMS_BASE}/client/res/data_smscdr.php"

ZENTO_SMS_USERNAME = ''
ZENTO_SMS_PASSWORD = ''

ZENTO_SMS_INTERVAL = 16

# ── Wolf SMS Panel ─────────────────────────────────────────────────────────────
WOLF_SMS_BASE       = "http://213.32.24.208/ints"
WOLF_SMS_LOGIN_URL  = "http://213.32.24.208/ints/login"
WOLF_SMS_SIGNIN_URL = "http://213.32.24.208/ints/signin"
WOLF_SMS_STATS_URL  = "http://213.32.24.208/ints/agent/SMSCDRStats"
WOLF_SMS_AJAX_URL   = "http://213.32.24.208/ints/agent/res/data_smscdr.php"

WOLF_SMS_USERNAME = ''
WOLF_SMS_PASSWORD = ''

WOLF_SMS_INTERVAL = 16

# ── Shark SMS Panel ────────────────────────────────────────────────────────────
SHARK_SMS_BASE       = "http://65.109.111.158/ints"
SHARK_SMS_LOGIN_URL  = "http://65.109.111.158/ints/login"
SHARK_SMS_SIGNIN_URL = "http://65.109.111.158/ints/signin"
SHARK_SMS_STATS_URL  = "http://65.109.111.158/ints/agent/SMSCDRStats"
SHARK_SMS_AJAX_URL   = "http://65.109.111.158/ints/agent/res/data_smscdr.php"

SHARK_SMS_USERNAME = ''
SHARK_SMS_PASSWORD = ''

SHARK_SMS_INTERVAL = 16

# ── SMS Hadi 2 Panel (Second Account — same server, different credentials) ──────
SMS_HADI2_BASE       = "http://smshadi.net"
SMS_HADI2_LOGIN_URL  = f"{SMS_HADI2_BASE}/login"
SMS_HADI2_SIGNIN_URL = f"{SMS_HADI2_BASE}/signin"
SMS_HADI2_STATS_URL  = f"{SMS_HADI2_BASE}/agent/SMSCDRStats"
SMS_HADI2_AJAX_URL   = f"{SMS_HADI2_BASE}/agent/res/data_smscdr.php"

SMS_HADI2_USERNAME = ''
SMS_HADI2_PASSWORD = ''

# ── KM Carrier SMS Panel ───────────────────────────────────────────────────────
KM_CARRIER_SMS_BASE       = "http://54.36.173.235/ints"
KM_CARRIER_SMS_LOGIN_URL  = f"{KM_CARRIER_SMS_BASE}/login"
KM_CARRIER_SMS_SIGNIN_URL = f"{KM_CARRIER_SMS_BASE}/signin"
KM_CARRIER_SMS_STATS_URL  = f"{KM_CARRIER_SMS_BASE}/agent/SMSCDRStats"
KM_CARRIER_SMS_AJAX_URL   = f"{KM_CARRIER_SMS_BASE}/agent/res/data_smscdr.php"

KM_CARRIER_SMS_USERNAME = ''
KM_CARRIER_SMS_PASSWORD = ''

KM_CARRIER_SMS_INTERVAL = 16

# ── Poll jitter & rate-limit back-off ─────────────────────────────────────────
# Applied by _jittered_sleep() in otp_monitor.py to randomise each panel's
# HTTP request cadence so all monitors never fire simultaneously.
#
# POLL_JITTER_FRAC  — fraction of the base interval added as ±random jitter.
#                     E.g. 0.25 on a 16-s interval → actual sleep is 12–20 s.
# BACKOFF_BASE_SECS — initial extra sleep on consecutive fetch failures.
# BACKOFF_MAX_SECS  — hard ceiling on exponential back-off.
# BACKOFF_MULTIPLIER — doubles the extra sleep each consecutive failure.
POLL_JITTER_FRAC   = 0.25   # ±25 % of base interval
BACKOFF_BASE_SECS  = 30     # 30 s initial back-off on consecutive errors
BACKOFF_MAX_SECS   = 300    # cap at 5 minutes
BACKOFF_MULTIPLIER = 2.0    # exponential growth factor
